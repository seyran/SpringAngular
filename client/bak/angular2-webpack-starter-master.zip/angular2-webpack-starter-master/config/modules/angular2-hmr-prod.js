exports.HmrState = function() {

}
